$('.flexslider').flexslider({

	randomize: true,
	slideshowSpeed: 3000,
	animation: "slide"

});