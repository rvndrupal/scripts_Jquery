$("ul#galeria li a").fancybox({

	openEffect  : 'elastic',
	closeEffect  : 'elastic',
	openSpeed: 150,
	closeSpeed: 150,
	helpers: {title: {type: "inside"}}

});